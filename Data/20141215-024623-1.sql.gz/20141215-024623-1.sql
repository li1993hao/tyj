-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : xjxt
-- 
-- Part : #1
-- Date : 2014-12-15 02:46:23
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `xj_action`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action`;
CREATE TABLE `xj_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `xj_action`
-- -----------------------------
INSERT INTO `xj_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `xj_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '1', '1380173180');
INSERT INTO `xj_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `xj_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '1', '1386139726');
INSERT INTO `xj_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '-1', '1418542406');
INSERT INTO `xj_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '-1', '1418542415');
INSERT INTO `xj_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `xj_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `xj_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `xj_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `xj_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '-1', '1418540966');

-- -----------------------------
-- Table structure for `xj_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action_log`;
CREATE TABLE `xj_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `xj_action_log`
-- -----------------------------
INSERT INTO `xj_action_log` VALUES ('35', '1', '1', '0', 'member', '1', '李浩在2014-12-14 15:10登录了后台', '1', '1418541024');
INSERT INTO `xj_action_log` VALUES ('37', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549477');
INSERT INTO `xj_action_log` VALUES ('38', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549498');
INSERT INTO `xj_action_log` VALUES ('39', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562900');
INSERT INTO `xj_action_log` VALUES ('40', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562928');
INSERT INTO `xj_action_log` VALUES ('41', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562987');
INSERT INTO `xj_action_log` VALUES ('42', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563003');
INSERT INTO `xj_action_log` VALUES ('43', '10', '1', '0', 'Menu', '138', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563420');
INSERT INTO `xj_action_log` VALUES ('44', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564245');
INSERT INTO `xj_action_log` VALUES ('45', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564491');
INSERT INTO `xj_action_log` VALUES ('46', '10', '1', '0', 'Menu', '148', '操作url：/tyj/Home/Menu/add.html', '1', '1418570074');
INSERT INTO `xj_action_log` VALUES ('47', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/add.html', '1', '1418570618');
INSERT INTO `xj_action_log` VALUES ('48', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/edit.html', '1', '1418570645');

-- -----------------------------
-- Table structure for `xj_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_extend`;
CREATE TABLE `xj_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `xj_auth_extend`
-- -----------------------------
INSERT INTO `xj_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `xj_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group`;
CREATE TABLE `xj_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group`
-- -----------------------------
INSERT INTO `xj_auth_group` VALUES ('3', 'admin', '1', '测试', '测试', '1', '245,246,248,249,250,251,252,253,259,261,262,263');
INSERT INTO `xj_auth_group` VALUES ('4', 'admin', '1', '随即', '少', '1', '245,246,248,249,250,251,252,253,259,260,261,262,263');

-- -----------------------------
-- Table structure for `xj_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group_access`;
CREATE TABLE `xj_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group_access`
-- -----------------------------
INSERT INTO `xj_auth_group_access` VALUES ('2', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '4');

-- -----------------------------
-- Table structure for `xj_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_rule`;
CREATE TABLE `xj_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=267 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_rule`
-- -----------------------------
INSERT INTO `xj_auth_rule` VALUES ('245', 'admin', '1', 'Home/menu/edit', '编辑', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('246', 'admin', '2', 'Home/Index/index', '主页', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('247', 'admin', '1', 'Home/user/index', '用户信息', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('248', 'admin', '2', 'Home/Public/index', '系统', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('249', 'admin', '1', 'Home/user/action', '用户行为', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('250', 'admin', '1', 'Home/authManager/index', '权限管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('251', 'admin', '1', 'Home/action/actionlog', '行为日志', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('252', 'admin', '1', 'Home/user/updatePassword', '修改密码', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('253', 'admin', '1', 'Home/user/updateNickname', '修改昵称', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('254', 'admin', '1', 'Home/a/b', 'cdshi', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('255', 'admin', '1', 'Home/Athlete/index', '运动员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('256', 'admin', '1', 'Home/Coach/index', '教练员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('257', 'admin', '1', 'Home/Judge/index', '裁判员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('258', 'admin', '1', 'Home/Equipe/index', '运动队管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('259', 'admin', '1', 'Home/menu/index', '菜单管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('260', 'admin', '1', 'Home/config/group', '网站设置', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('261', 'admin', '1', 'Home/menu/add', '新增', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('262', 'admin', '1', 'Home/menu/del', '删除', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('263', 'admin', '1', 'Home/menu/import', '导入', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('264', 'admin', '1', 'Home/database/exportIndex', '备份数据库', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('265', 'admin', '1', 'Home/database/importIndex', '还原数据库', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('266', 'admin', '1', 'Home/config/index', '配置管理', '1', '');

-- -----------------------------
-- Table structure for `xj_config`
-- -----------------------------
DROP TABLE IF EXISTS `xj_config`;
CREATE TABLE `xj_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_config`
-- -----------------------------
INSERT INTO `xj_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'OneThink内容管理框架', '1');
INSERT INTO `xj_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'OneThink内容管理框架', '2');
INSERT INTO `xj_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,OneThink', '9');
INSERT INTO `xj_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '6');
INSERT INTO `xj_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '14');
INSERT INTO `xj_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '15');
INSERT INTO `xj_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '5');
INSERT INTO `xj_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '7');
INSERT INTO `xj_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '16');
INSERT INTO `xj_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '10');
INSERT INTO `xj_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '11');
INSERT INTO `xj_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '19');
INSERT INTO `xj_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '20');
INSERT INTO `xj_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '21');
INSERT INTO `xj_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '4');
INSERT INTO `xj_config` VALUES ('38', 'SWSASQ', '0', 'ssss', '1', '', '', '1418582713', '1418582744', '1', 'ssqs', '0');
INSERT INTO `xj_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '17');
INSERT INTO `xj_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '8');
INSERT INTO `xj_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '18');
INSERT INTO `xj_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '22');
INSERT INTO `xj_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '24');
INSERT INTO `xj_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '3');
INSERT INTO `xj_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '12');
INSERT INTO `xj_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '23');
INSERT INTO `xj_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '25');
INSERT INTO `xj_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '13');

-- -----------------------------
-- Table structure for `xj_file`
-- -----------------------------
DROP TABLE IF EXISTS `xj_file`;
CREATE TABLE `xj_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `xj_member`
-- -----------------------------
DROP TABLE IF EXISTS `xj_member`;
CREATE TABLE `xj_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(40) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `login_times` int(11) DEFAULT '0',
  `nickname` char(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `xj_member`
-- -----------------------------
INSERT INTO `xj_member` VALUES ('1', 'admin', 'f61dab13255ee02ee71569aafb1b11653b007cbe', '953445224@qq.com', '', '1415582883', '0', '1418541035', '0', '1415582883', '1', '33', '李浩');
INSERT INTO `xj_member` VALUES ('2', 'lihao', 'f3d74f5557895491f35d2cd688aaee8127080a43', '953445223@qq.com', '', '1418455631', '0', '1418499321', '0', '1418491475', '1', '20', 'lihao');
INSERT INTO `xj_member` VALUES ('3', 'lihao123', '5c4551bc7063089af4580de7faf05f30d0ee857a', '953445222@qq.com', '', '1418455805', '0', '0', '0', '1418455805', '1', '0', 'lihao123');

-- -----------------------------
-- Table structure for `xj_menu`
-- -----------------------------
DROP TABLE IF EXISTS `xj_menu`;
CREATE TABLE `xj_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_menu`
-- -----------------------------
INSERT INTO `xj_menu` VALUES ('134', '新增', '128', '0', 'menu/add', '0', '新增菜单dasdasd', '', '0');
INSERT INTO `xj_menu` VALUES ('135', '删除', '128', '0', 'menu/del', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('136', '导入', '128', '0', 'menu/import', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('137', '编辑', '128', '0', 'menu/edit', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('138', '主页', '0', '1', 'Index/index', '0', '这个是主页', '', '0');
INSERT INTO `xj_menu` VALUES ('141', '用户信息', '140', '0', 'user/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('140', '用户', '0', '2', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('142', '用户行为', '140', '0', 'user/action', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('143', '权限管理', '140', '0', 'authManager/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('144', '行为日志', '140', '0', 'action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('145', '修改密码', '140', '0', 'user/updatePassword', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('146', '修改昵称', '140', '0', 'user/updateNickname', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('147', 'cdshi', '141', '0', 'a/b', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('7', '运动员管理', '2', '1', 'Athlete/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('4', '人员服务', '0', '3', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('125', '教练员管理', '2', '2', 'Coach/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('126', '裁判员管理', '2', '3', 'Judge/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('127', '运动队管理', '2', '4', 'Equipe/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('128', '菜单管理', '6', '6', 'menu/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('129', '备份数据库', '6', '6', 'database/exportIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('130', '还原数据库', '6', '6', 'database/importIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('6', '系统', '0', '4', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('148', '网站设置', '6', '0', 'config/group', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('149', '配置管理', '6', '0', 'config/index', '0', '', '系统设置', '0');

-- -----------------------------
-- Table structure for `xj_picture`
-- -----------------------------
DROP TABLE IF EXISTS `xj_picture`;
CREATE TABLE `xj_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_picture`
-- -----------------------------
INSERT INTO `xj_picture` VALUES ('1', '/Uploads/Picture/2014-11-13/54642c43484a9.jpg', '', '71dc21797cfb7dca66515adcc4abe93b', 'f96f72d919ce79498f8608a647e5ab534c12c9ab', '1', '1415851075');
INSERT INTO `xj_picture` VALUES ('2', '/Uploads/Picture/2014-11-20/546dc0c7c7ef4.png', '', 'd8438e506d466ed38ee6b9dc4a232b40', 'b1191b0a06d36f92bb9fb21bc94daaab80265f03', '1', '1416478919');
INSERT INTO `xj_picture` VALUES ('3', '/Uploads/Picture/2014-11-21/546ec9e8d24ec.png', '', '5d1d5d4195258797a0b6fcffadcd8511', '5e6d0c581d800dd0622a76f091b2701456f8e351', '1', '1416546792');
INSERT INTO `xj_picture` VALUES ('4', '/Uploads/Picture/2014-11-21/546ed0ddc3cba.png', '', '3c838b9f71bc517a3b8028415bb59cb1', '09ac100f01411da86664b69250aba8f0b83d1491', '1', '1416548573');
INSERT INTO `xj_picture` VALUES ('5', '/Uploads/Picture/2014-11-21/546edffc7d2a6.png', '', '2f2493b43169047408921c245572d250', 'b108c0a832627b36e047a473231221e9d58619a2', '1', '1416552444');
INSERT INTO `xj_picture` VALUES ('6', '/Uploads/Picture/2014-11-21/546ee04d260c2.png', '', '333e3d1dd2ca98d7e989131b7d9a338f', '45e103b823372a5a033d9d317008c7ed218752f9', '1', '1416552525');
INSERT INTO `xj_picture` VALUES ('7', '/Uploads/Picture/2014-11-21/546ee16ca61b1.png', '', '2791e727022d2d863e17a02e57c8237f', 'eb067c0e3dbe17297247c7307b956daab3ea0bad', '1', '1416552812');
INSERT INTO `xj_picture` VALUES ('8', '/Uploads/Picture/2014-11-21/546ee1c64539c.png', '', 'f9d7f9a78cc852a599bc301cda134145', 'ef2502b45938da6de9c7321b428737eb4d9a3884', '1', '1416552902');
