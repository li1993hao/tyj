-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : xjxt
-- 
-- Part : #1
-- Date : 2014-12-17 20:51:06
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `xj_action`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action`;
CREATE TABLE `xj_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `xj_action`
-- -----------------------------
INSERT INTO `xj_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `xj_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '1', '1380173180');
INSERT INTO `xj_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `xj_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '1', '1386139726');
INSERT INTO `xj_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '-1', '1418542406');
INSERT INTO `xj_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '-1', '1418542415');
INSERT INTO `xj_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `xj_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `xj_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `xj_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `xj_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '-1', '1418540966');

-- -----------------------------
-- Table structure for `xj_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action_log`;
CREATE TABLE `xj_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `xj_action_log`
-- -----------------------------
INSERT INTO `xj_action_log` VALUES ('35', '1', '1', '0', 'member', '1', '李浩在2014-12-14 15:10登录了后台', '1', '1418541024');
INSERT INTO `xj_action_log` VALUES ('37', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549477');
INSERT INTO `xj_action_log` VALUES ('38', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549498');
INSERT INTO `xj_action_log` VALUES ('39', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562900');
INSERT INTO `xj_action_log` VALUES ('40', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562928');
INSERT INTO `xj_action_log` VALUES ('41', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562987');
INSERT INTO `xj_action_log` VALUES ('42', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563003');
INSERT INTO `xj_action_log` VALUES ('43', '10', '1', '0', 'Menu', '138', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563420');
INSERT INTO `xj_action_log` VALUES ('44', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564245');
INSERT INTO `xj_action_log` VALUES ('45', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564491');
INSERT INTO `xj_action_log` VALUES ('46', '10', '1', '0', 'Menu', '148', '操作url：/tyj/Home/Menu/add.html', '1', '1418570074');
INSERT INTO `xj_action_log` VALUES ('47', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/add.html', '1', '1418570618');
INSERT INTO `xj_action_log` VALUES ('48', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/edit.html', '1', '1418570645');
INSERT INTO `xj_action_log` VALUES ('49', '10', '1', '0', 'Menu', '150', '操作url：/tyj/Home/Menu/add.html', '1', '1418646311');
INSERT INTO `xj_action_log` VALUES ('50', '10', '1', '0', 'Menu', '151', '操作url：/tyj/Home/Menu/add.html', '1', '1418646368');
INSERT INTO `xj_action_log` VALUES ('51', '10', '1', '0', 'Menu', '152', '操作url：/tyj/Home/Menu/add.html', '1', '1418646841');
INSERT INTO `xj_action_log` VALUES ('52', '1', '1', '0', 'member', '1', '李浩在2014-12-16 10:23登录了后台', '1', '1418696606');
INSERT INTO `xj_action_log` VALUES ('53', '1', '1', '0', 'member', '1', '李浩在2014-12-16 10:23登录了后台', '1', '1418696616');
INSERT INTO `xj_action_log` VALUES ('54', '7', '1', '0', 'model', '5', '操作url：/tyj/Admin/Model/update.html', '1', '1418702724');
INSERT INTO `xj_action_log` VALUES ('55', '8', '1', '0', 'attribute', '39', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418706206');
INSERT INTO `xj_action_log` VALUES ('56', '8', '1', '0', 'attribute', '39', '操作url：/tyj/Admin/Attribute/remove/id/39.html', '1', '1418708345');
INSERT INTO `xj_action_log` VALUES ('57', '8', '1', '0', 'attribute', '40', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708409');
INSERT INTO `xj_action_log` VALUES ('58', '8', '1', '0', 'attribute', '41', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708601');
INSERT INTO `xj_action_log` VALUES ('59', '8', '1', '0', 'attribute', '42', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708645');
INSERT INTO `xj_action_log` VALUES ('60', '8', '1', '0', 'attribute', '42', '操作url：/tyj/Admin/Attribute/remove/id/42.html', '1', '1418708691');
INSERT INTO `xj_action_log` VALUES ('61', '8', '1', '0', 'attribute', '41', '操作url：/tyj/Admin/Attribute/remove/id/41.html', '1', '1418708699');
INSERT INTO `xj_action_log` VALUES ('62', '8', '1', '0', 'attribute', '40', '操作url：/tyj/Admin/Attribute/remove/id/40.html', '1', '1418708714');
INSERT INTO `xj_action_log` VALUES ('63', '8', '1', '0', 'attribute', '43', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418710689');
INSERT INTO `xj_action_log` VALUES ('64', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418711568');
INSERT INTO `xj_action_log` VALUES ('65', '8', '1', '0', 'attribute', '50', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418711609');
INSERT INTO `xj_action_log` VALUES ('66', '8', '1', '0', 'attribute', '50', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418711631');
INSERT INTO `xj_action_log` VALUES ('67', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418714595');
INSERT INTO `xj_action_log` VALUES ('68', '8', '1', '0', 'attribute', '51', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418714765');
INSERT INTO `xj_action_log` VALUES ('69', '7', '1', '0', 'model', '7', '操作url：/tyj/Admin/Model/update.html', '1', '1418719028');
INSERT INTO `xj_action_log` VALUES ('70', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418719044');
INSERT INTO `xj_action_log` VALUES ('71', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418727884');
INSERT INTO `xj_action_log` VALUES ('72', '8', '1', '0', 'attribute', '54', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418728004');
INSERT INTO `xj_action_log` VALUES ('73', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418728445');
INSERT INTO `xj_action_log` VALUES ('74', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418728474');
INSERT INTO `xj_action_log` VALUES ('75', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:38登录了后台', '1', '1418729884');
INSERT INTO `xj_action_log` VALUES ('76', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:38登录了后台', '1', '1418729900');
INSERT INTO `xj_action_log` VALUES ('77', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:44登录了后台', '1', '1418730283');
INSERT INTO `xj_action_log` VALUES ('78', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:50登录了后台', '1', '1418730609');
INSERT INTO `xj_action_log` VALUES ('79', '8', '1', '0', 'attribute', '55', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418732002');
INSERT INTO `xj_action_log` VALUES ('80', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418734613');
INSERT INTO `xj_action_log` VALUES ('81', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418735297');
INSERT INTO `xj_action_log` VALUES ('82', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418735678');
INSERT INTO `xj_action_log` VALUES ('83', '8', '1', '0', 'attribute', '56', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418735715');
INSERT INTO `xj_action_log` VALUES ('84', '8', '1', '0', 'attribute', '57', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418735756');
INSERT INTO `xj_action_log` VALUES ('85', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418735920');
INSERT INTO `xj_action_log` VALUES ('86', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736083');
INSERT INTO `xj_action_log` VALUES ('87', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736109');
INSERT INTO `xj_action_log` VALUES ('88', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736217');
INSERT INTO `xj_action_log` VALUES ('89', '8', '1', '0', 'attribute', '58', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418736690');
INSERT INTO `xj_action_log` VALUES ('90', '8', '1', '0', 'attribute', '59', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418736789');
INSERT INTO `xj_action_log` VALUES ('91', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736844');
INSERT INTO `xj_action_log` VALUES ('92', '8', '1', '0', 'attribute', '56', '操作url：/tyj/Admin/Attribute/remove/id/56.html', '1', '1418736914');
INSERT INTO `xj_action_log` VALUES ('93', '8', '1', '0', 'attribute', '60', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737432');
INSERT INTO `xj_action_log` VALUES ('94', '8', '1', '0', 'attribute', '61', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737599');
INSERT INTO `xj_action_log` VALUES ('95', '8', '1', '0', 'attribute', '62', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737615');
INSERT INTO `xj_action_log` VALUES ('96', '8', '1', '0', 'attribute', '63', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737823');
INSERT INTO `xj_action_log` VALUES ('97', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418738823');
INSERT INTO `xj_action_log` VALUES ('98', '8', '1', '0', 'attribute', '68', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418738946');
INSERT INTO `xj_action_log` VALUES ('99', '8', '1', '0', 'attribute', '69', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418739032');
INSERT INTO `xj_action_log` VALUES ('100', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739159');
INSERT INTO `xj_action_log` VALUES ('101', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739184');
INSERT INTO `xj_action_log` VALUES ('102', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739205');
INSERT INTO `xj_action_log` VALUES ('103', '1', '1', '0', 'member', '1', '李浩在2014-12-17 00:20登录了后台', '1', '1418746804');
INSERT INTO `xj_action_log` VALUES ('104', '1', '1', '0', 'member', '1', '李浩在2014-12-17 12:45登录了后台', '1', '1418791537');
INSERT INTO `xj_action_log` VALUES ('105', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418802016');
INSERT INTO `xj_action_log` VALUES ('106', '8', '1', '0', 'attribute', '82', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802074');
INSERT INTO `xj_action_log` VALUES ('107', '8', '1', '0', 'attribute', '83', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802189');
INSERT INTO `xj_action_log` VALUES ('108', '8', '1', '0', 'attribute', '84', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802338');
INSERT INTO `xj_action_log` VALUES ('109', '8', '1', '0', 'attribute', '85', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802392');
INSERT INTO `xj_action_log` VALUES ('110', '8', '1', '0', 'attribute', '86', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802915');
INSERT INTO `xj_action_log` VALUES ('111', '8', '1', '0', 'attribute', '87', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803034');
INSERT INTO `xj_action_log` VALUES ('112', '8', '1', '0', 'attribute', '88', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803183');
INSERT INTO `xj_action_log` VALUES ('113', '8', '1', '0', 'attribute', '89', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803554');
INSERT INTO `xj_action_log` VALUES ('114', '8', '1', '0', 'attribute', '90', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803597');
INSERT INTO `xj_action_log` VALUES ('115', '8', '1', '0', 'attribute', '83', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803756');
INSERT INTO `xj_action_log` VALUES ('116', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418803993');
INSERT INTO `xj_action_log` VALUES ('117', '8', '1', '0', 'attribute', '89', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418804042');
INSERT INTO `xj_action_log` VALUES ('118', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418806200');
INSERT INTO `xj_action_log` VALUES ('119', '8', '1', '0', 'attribute', '86', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418806399');
INSERT INTO `xj_action_log` VALUES ('120', '1', '1', '0', 'member', '1', '李浩在2014-12-17 20:47登录了后台', '1', '1418820422');
INSERT INTO `xj_action_log` VALUES ('121', '7', '1', '0', 'model', '19', '操作url：/tyj/Admin/Model/update.html', '1', '1418820444');

-- -----------------------------
-- Table structure for `xj_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `xj_attribute`;
CREATE TABLE `xj_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  `validate_condition` tinyint(1) NOT NULL DEFAULT '0' COMMENT '验证条件',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `xj_attribute`
-- -----------------------------
INSERT INTO `xj_attribute` VALUES ('82', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '1', '1', '1418802074', '1418802074', '6,255', '3', '标题长度要在6到255之间', 'length', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('83', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('84', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('85', 'description', '描述', 'text NOT NULL', 'textarea', '', '内容描述', '1', '', '18', '1', '1', '1418802392', '1418802392', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('86', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '0', '1', '1418806399', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('87', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期', '1', '', '18', '0', '1', '1418803034', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('88', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '18', '0', '1', '1418803184', '1418803184', '/^[1-9]\\d*$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('89', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '', '1', '', '18', '0', '1', '1418804042', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('90', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');

-- -----------------------------
-- Table structure for `xj_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_extend`;
CREATE TABLE `xj_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `xj_auth_extend`
-- -----------------------------
INSERT INTO `xj_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `xj_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `xj_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `xj_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group`;
CREATE TABLE `xj_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group`
-- -----------------------------
INSERT INTO `xj_auth_group` VALUES ('3', 'admin', '1', '测试', '测试', '1', '271,277,280,281');
INSERT INTO `xj_auth_group` VALUES ('4', 'admin', '1', '随即', '少', '1', '268,271,277,280,281,288');

-- -----------------------------
-- Table structure for `xj_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group_access`;
CREATE TABLE `xj_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group_access`
-- -----------------------------
INSERT INTO `xj_auth_group_access` VALUES ('2', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '4');

-- -----------------------------
-- Table structure for `xj_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_rule`;
CREATE TABLE `xj_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=291 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_rule`
-- -----------------------------
INSERT INTO `xj_auth_rule` VALUES ('245', 'admin', '1', 'Home/menu/edit', '编辑', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('246', 'admin', '2', 'Home/Index/index', '主页', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('247', 'admin', '1', 'Home/user/index', '用户信息', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('248', 'admin', '2', 'Home/Public/index', '系统', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('249', 'admin', '1', 'Home/user/action', '用户行为', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('250', 'admin', '1', 'Home/authManager/index', '权限管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('251', 'admin', '1', 'Home/action/actionlog', '行为日志', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('252', 'admin', '1', 'Home/user/updatePassword', '修改密码', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('253', 'admin', '1', 'Home/user/updateNickname', '修改昵称', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('254', 'admin', '1', 'Home/a/b', 'cdshi', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('255', 'admin', '1', 'Home/Athlete/index', '运动员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('256', 'admin', '1', 'Home/Coach/index', '教练员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('257', 'admin', '1', 'Home/Judge/index', '裁判员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('258', 'admin', '1', 'Home/Equipe/index', '运动队管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('259', 'admin', '1', 'Home/menu/index', '菜单管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('260', 'admin', '1', 'Home/config/group', '网站设置', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('261', 'admin', '1', 'Home/menu/add', '新增', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('262', 'admin', '1', 'Home/menu/del', '删除', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('263', 'admin', '1', 'Home/menu/import', '导入', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('264', 'admin', '1', 'Home/database/exportIndex', '备份数据库', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('265', 'admin', '1', 'Home/database/importIndex', '还原数据库', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('266', 'admin', '1', 'Home/config/index', '配置管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('267', 'admin', '1', 'Admin/menu/add', '新增', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('268', 'admin', '1', 'Admin/menu/del', '删除', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('269', 'admin', '1', 'Admin/menu/import', '导入', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('270', 'admin', '1', 'Admin/menu/edit', '编辑', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('271', 'admin', '1', 'Admin/user/index', '用户信息', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('272', 'admin', '1', 'Admin/user/action', '用户行为', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('273', 'admin', '1', 'Admin/authManager/index', '权限管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('274', 'admin', '1', 'Admin/action/actionlog', '行为日志', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('275', 'admin', '1', 'Admin/user/updatePassword', '修改密码', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('276', 'admin', '1', 'Admin/user/updateNickname', '修改昵称', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('277', 'admin', '1', 'Admin/a/b', 'cdshi', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('278', 'admin', '1', 'Admin/config/group', '网站设置', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('279', 'admin', '1', 'Admin/config/index', '配置管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('280', 'admin', '2', 'Admin/Public/index', '系统', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Category/index', '栏目管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('282', 'admin', '1', 'Admin/model/index', '模型管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('283', 'admin', '2', 'Admin/Index/index', '主页', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('284', 'admin', '1', 'Admin/Athlete/index', '运动员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('285', 'admin', '1', 'Admin/Coach/index', '教练员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('286', 'admin', '1', 'Admin/Judge/index', '裁判员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('287', 'admin', '1', 'Admin/Equipe/index', '运动队管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('288', 'admin', '1', 'Admin/menu/index', '菜单管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('289', 'admin', '1', 'Admin/database/exportIndex', '备份数据库', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('290', 'admin', '1', 'Admin/database/importIndex', '还原数据库', '1', '');

-- -----------------------------
-- Table structure for `xj_base_article`
-- -----------------------------
DROP TABLE IF EXISTS `xj_base_article`;
CREATE TABLE `xj_base_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` text NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `xj_config`
-- -----------------------------
DROP TABLE IF EXISTS `xj_config`;
CREATE TABLE `xj_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_config`
-- -----------------------------
INSERT INTO `xj_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'OneThink内容管理框架', '1');
INSERT INTO `xj_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'OneThink内容管理框架', '2');
INSERT INTO `xj_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,OneThink', '9');
INSERT INTO `xj_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '6');
INSERT INTO `xj_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '14');
INSERT INTO `xj_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '15');
INSERT INTO `xj_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '5');
INSERT INTO `xj_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '7');
INSERT INTO `xj_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '16');
INSERT INTO `xj_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '10');
INSERT INTO `xj_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '11');
INSERT INTO `xj_config` VALUES ('40', 'TEMP_PATH', '2', '前台模版路径', '2', '', '内容显示的模版路径', '1418650622', '1418651066', '1', './Template', '0');
INSERT INTO `xj_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '20');
INSERT INTO `xj_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '21');
INSERT INTO `xj_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '4');
INSERT INTO `xj_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '17');
INSERT INTO `xj_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '8');
INSERT INTO `xj_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '18');
INSERT INTO `xj_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '22');
INSERT INTO `xj_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '24');
INSERT INTO `xj_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '3');
INSERT INTO `xj_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '12');
INSERT INTO `xj_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '23');
INSERT INTO `xj_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '25');
INSERT INTO `xj_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '13');

-- -----------------------------
-- Table structure for `xj_document`
-- -----------------------------
DROP TABLE IF EXISTS `xj_document`;
CREATE TABLE `xj_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `xj_document`
-- -----------------------------
INSERT INTO `xj_document` VALUES ('1', '我是李浩', '12');

-- -----------------------------
-- Table structure for `xj_exlink`
-- -----------------------------
DROP TABLE IF EXISTS `xj_exlink`;
CREATE TABLE `xj_exlink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_id` int(10) NOT NULL COMMENT '图片外键',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `url` varchar(200) NOT NULL COMMENT 'url链接',
  `sort` int(11) NOT NULL COMMENT '排序',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_file`
-- -----------------------------
DROP TABLE IF EXISTS `xj_file`;
CREATE TABLE `xj_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `xj_file`
-- -----------------------------
INSERT INTO `xj_file` VALUES ('11', 'article.model', '548ee0cd838ad.model', '2014-12-15/', 'model', 'text/plain', '208', '08a4b8435d1412147c870104a8e34bf8', '118b6e9b4572c145e7bc51866a307669539eafde', '0', '1418649805');
INSERT INTO `xj_file` VALUES ('10', '546972193c65c.model', '548eddb58b4ee.model', '2014-12-15/', 'model', 'text/plain', '221', '38b086ec6301e686b9124c736c60df7b', 'f0c04950ab0bf45998051f97b3974a0892ab051e', '0', '1418649013');

-- -----------------------------
-- Table structure for `xj_link_group`
-- -----------------------------
DROP TABLE IF EXISTS `xj_link_group`;
CREATE TABLE `xj_link_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '0表示可以有文字或者图片，1表示只能是文字，3表示必须有图片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_member`
-- -----------------------------
DROP TABLE IF EXISTS `xj_member`;
CREATE TABLE `xj_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(40) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `login_times` int(11) DEFAULT '0',
  `nickname` char(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `xj_member`
-- -----------------------------
INSERT INTO `xj_member` VALUES ('1', 'admin', 'f61dab13255ee02ee71569aafb1b11653b007cbe', '953445224@qq.com', '', '1415582883', '0', '1418820422', '0', '1415582883', '1', '50', '李浩');
INSERT INTO `xj_member` VALUES ('2', 'lihao', 'f3d74f5557895491f35d2cd688aaee8127080a43', '953445223@qq.com', '', '1418455631', '0', '1418499321', '0', '1418491475', '1', '20', 'lihao');
INSERT INTO `xj_member` VALUES ('3', 'lihao123', '5c4551bc7063089af4580de7faf05f30d0ee857a', '953445222@qq.com', '', '1418455805', '0', '0', '0', '1418455805', '1', '0', 'lihao123');

-- -----------------------------
-- Table structure for `xj_menu`
-- -----------------------------
DROP TABLE IF EXISTS `xj_menu`;
CREATE TABLE `xj_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=153 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_menu`
-- -----------------------------
INSERT INTO `xj_menu` VALUES ('134', '新增', '128', '0', 'menu/add', '0', '新增菜单dasdasd', '', '0');
INSERT INTO `xj_menu` VALUES ('135', '删除', '128', '0', 'menu/del', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('136', '导入', '128', '0', 'menu/import', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('137', '编辑', '128', '0', 'menu/edit', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('138', '主页', '0', '1', 'Index/index', '0', '这个是主页', '', '0');
INSERT INTO `xj_menu` VALUES ('141', '用户信息', '140', '0', 'user/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('140', '用户', '0', '2', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('142', '用户行为', '140', '0', 'user/action', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('143', '权限管理', '140', '0', 'authManager/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('144', '行为日志', '140', '0', 'action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('145', '修改密码', '140', '0', 'user/updatePassword', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('146', '修改昵称', '140', '0', 'user/updateNickname', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('147', 'cdshi', '141', '0', 'a/b', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('7', '运动员管理', '2', '1', 'Athlete/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('4', '人员服务', '0', '3', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('125', '教练员管理', '2', '2', 'Coach/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('126', '裁判员管理', '2', '3', 'Judge/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('127', '运动队管理', '2', '4', 'Equipe/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('128', '菜单管理', '6', '6', 'menu/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('129', '备份数据库', '6', '6', 'database/exportIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('130', '还原数据库', '6', '6', 'database/importIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('6', '系统', '0', '4', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('148', '网站设置', '6', '0', 'config/group', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('149', '配置管理', '6', '0', 'config/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('150', '内容', '0', '0', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('151', '栏目管理', '150', '0', 'Category/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('152', '模型管理', '6', '0', 'model/index', '0', '', '', '0');

-- -----------------------------
-- Table structure for `xj_model`
-- -----------------------------
DROP TABLE IF EXISTS `xj_model`;
CREATE TABLE `xj_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `type` tinyint(3) unsigned NOT NULL,
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  `pid` int(10) NOT NULL COMMENT '父id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `xj_model`
-- -----------------------------
INSERT INTO `xj_model` VALUES ('19', 'download', '下载', '', '1:基础', '', '', '', '', '', '', '10', '', '', '1418820444', '1418820444', '1', '0', 'MyISAM', '0');
INSERT INTO `xj_model` VALUES ('18', 'base_article', '基础文档', '{\"1\":[\"82\",\"85\",\"86\"],\"2\":[\"88\",\"89\",\"87\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', '', '', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '10', 'title', '', '1418802016', '1418806200', '1', '0', 'MyISAM', '0');

-- -----------------------------
-- Table structure for `xj_node`
-- -----------------------------
DROP TABLE IF EXISTS `xj_node`;
CREATE TABLE `xj_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) unsigned NOT NULL COMMENT '1是栏目,2是单页面,3是外部链接',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `symbol` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目英文名称',
  `pid` int(11) NOT NULL COMMENT '父级栏目',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序字段',
  `model_id` int(11) NOT NULL DEFAULT '0' COMMENT '模型',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_user` int(11) NOT NULL DEFAULT '0' COMMENT '创建者',
  `temp_category` char(40) NOT NULL DEFAULT '' COMMENT '栏目页模版',
  `temp_list` char(40) NOT NULL DEFAULT '' COMMENT '列表页模版',
  `temp_content` char(40) NOT NULL DEFAULT '' COMMENT '内容页模版',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '要跳转的url',
  `list_num` int(11) NOT NULL COMMENT '每页显示的记录数量',
  `index_show` tinyint(1) DEFAULT '1' COMMENT '是否在主页显示',
  `status` tinyint(1) DEFAULT '0' COMMENT '-1代表以删除,0代表禁用,1代表正常',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_node`
-- -----------------------------
INSERT INTO `xj_node` VALUES ('2', '1', '一级栏目', 'yijilanmu', '0', '1', '1', '1418653214', '1418653214', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1');
INSERT INTO `xj_node` VALUES ('3', '2', '一级栏目', 'yijilanmu', '0', '0', '1', '1418653951', '1418653951', '0', '', '', 'content.html', '', '0', '1', '1');
INSERT INTO `xj_node` VALUES ('4', '2', '一级栏目2', 'yijilanmu2', '0', '0', '1', '1418654068', '1418654068', '0', '', '', 'content.html', '', '0', '1', '1');
INSERT INTO `xj_node` VALUES ('5', '1', '二级栏目', 'erjilanmu', '0', '0', '1', '1418654158', '1418654158', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1');
INSERT INTO `xj_node` VALUES ('6', '1', 'qsqswqsqw', 'sqwsqsq', '0', '0', '1', '1418654321', '1418654321', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1');
INSERT INTO `xj_node` VALUES ('7', '1', 'sadadasd', 'dsdsdsa', '2', '2', '1', '1418654411', '1418654411', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1');
INSERT INTO `xj_node` VALUES ('8', '1', 'sasasd', 'dsdasdasd', '7', '0', '1', '1418654427', '1418654427', '0', 'category.html', 'list.html', 'content.html', '', '20', '1', '1');
INSERT INTO `xj_node` VALUES ('9', '1', 'qdqdqd', 'qdqdqdq', '7', '3', '1', '1418654452', '1418654452', '0', 'category.html', 'list.html', 'content.html', '', '11', '1', '1');
INSERT INTO `xj_node` VALUES ('10', '2', 'sadasd', 'sadasdas', '0', '0', '1', '1418655926', '1418655926', '0', '', '', 'content.html', '', '0', '1', '1');
INSERT INTO `xj_node` VALUES ('11', '3', 'dsada', 'dsada', '0', '0', '0', '1418656019', '1418656019', '0', '', '', '', 'http://www.baidu.com', '0', '1', '1');

-- -----------------------------
-- Table structure for `xj_picture`
-- -----------------------------
DROP TABLE IF EXISTS `xj_picture`;
CREATE TABLE `xj_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_picture`
-- -----------------------------
INSERT INTO `xj_picture` VALUES ('1', '/Uploads/Picture/2014-11-13/54642c43484a9.jpg', '', '71dc21797cfb7dca66515adcc4abe93b', 'f96f72d919ce79498f8608a647e5ab534c12c9ab', '1', '1415851075');
INSERT INTO `xj_picture` VALUES ('2', '/Uploads/Picture/2014-11-20/546dc0c7c7ef4.png', '', 'd8438e506d466ed38ee6b9dc4a232b40', 'b1191b0a06d36f92bb9fb21bc94daaab80265f03', '1', '1416478919');
INSERT INTO `xj_picture` VALUES ('3', '/Uploads/Picture/2014-11-21/546ec9e8d24ec.png', '', '5d1d5d4195258797a0b6fcffadcd8511', '5e6d0c581d800dd0622a76f091b2701456f8e351', '1', '1416546792');
INSERT INTO `xj_picture` VALUES ('4', '/Uploads/Picture/2014-11-21/546ed0ddc3cba.png', '', '3c838b9f71bc517a3b8028415bb59cb1', '09ac100f01411da86664b69250aba8f0b83d1491', '1', '1416548573');
INSERT INTO `xj_picture` VALUES ('5', '/Uploads/Picture/2014-11-21/546edffc7d2a6.png', '', '2f2493b43169047408921c245572d250', 'b108c0a832627b36e047a473231221e9d58619a2', '1', '1416552444');
INSERT INTO `xj_picture` VALUES ('6', '/Uploads/Picture/2014-11-21/546ee04d260c2.png', '', '333e3d1dd2ca98d7e989131b7d9a338f', '45e103b823372a5a033d9d317008c7ed218752f9', '1', '1416552525');
INSERT INTO `xj_picture` VALUES ('7', '/Uploads/Picture/2014-11-21/546ee16ca61b1.png', '', '2791e727022d2d863e17a02e57c8237f', 'eb067c0e3dbe17297247c7307b956daab3ea0bad', '1', '1416552812');
INSERT INTO `xj_picture` VALUES ('8', '/Uploads/Picture/2014-11-21/546ee1c64539c.png', '', 'f9d7f9a78cc852a599bc301cda134145', 'ef2502b45938da6de9c7321b428737eb4d9a3884', '1', '1416552902');

-- -----------------------------
-- Table structure for `xj_position`
-- -----------------------------
DROP TABLE IF EXISTS `xj_position`;
CREATE TABLE `xj_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(60) NOT NULL,
  `model_category` char(30) NOT NULL,
  `create_time` int(11) NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_rel_position`
-- -----------------------------
DROP TABLE IF EXISTS `xj_rel_position`;
CREATE TABLE `xj_rel_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) NOT NULL,
  `model_name` char(40) NOT NULL,
  `news_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

