-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : xjxt
-- 
-- Part : #1
-- Date : 2014-12-20 21:37:57
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `xj_action`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action`;
CREATE TABLE `xj_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `xj_action`
-- -----------------------------
INSERT INTO `xj_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `xj_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '1', '1380173180');
INSERT INTO `xj_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `xj_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '1', '1386139726');
INSERT INTO `xj_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '-1', '1418542406');
INSERT INTO `xj_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '-1', '1418542415');
INSERT INTO `xj_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `xj_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `xj_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '-1', '1418890941');
INSERT INTO `xj_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `xj_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '-1', '1418540966');

-- -----------------------------
-- Table structure for `xj_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `xj_action_log`;
CREATE TABLE `xj_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `xj_action_log`
-- -----------------------------
INSERT INTO `xj_action_log` VALUES ('35', '1', '1', '0', 'member', '1', '李浩在2014-12-14 15:10登录了后台', '1', '1418541024');
INSERT INTO `xj_action_log` VALUES ('37', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549477');
INSERT INTO `xj_action_log` VALUES ('38', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418549498');
INSERT INTO `xj_action_log` VALUES ('39', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562900');
INSERT INTO `xj_action_log` VALUES ('40', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562928');
INSERT INTO `xj_action_log` VALUES ('41', '10', '1', '0', 'Menu', '130', '操作url：/tyj/Home/Menu/edit.html', '1', '1418562987');
INSERT INTO `xj_action_log` VALUES ('42', '10', '1', '0', 'Menu', '129', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563003');
INSERT INTO `xj_action_log` VALUES ('43', '10', '1', '0', 'Menu', '138', '操作url：/tyj/Home/Menu/edit.html', '1', '1418563420');
INSERT INTO `xj_action_log` VALUES ('44', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564245');
INSERT INTO `xj_action_log` VALUES ('45', '10', '1', '0', 'Menu', '134', '操作url：/tyj/Home/Menu/edit.html', '1', '1418564491');
INSERT INTO `xj_action_log` VALUES ('46', '10', '1', '0', 'Menu', '148', '操作url：/tyj/Home/Menu/add.html', '1', '1418570074');
INSERT INTO `xj_action_log` VALUES ('47', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/add.html', '1', '1418570618');
INSERT INTO `xj_action_log` VALUES ('48', '10', '1', '0', 'Menu', '149', '操作url：/tyj/Home/Menu/edit.html', '1', '1418570645');
INSERT INTO `xj_action_log` VALUES ('49', '10', '1', '0', 'Menu', '150', '操作url：/tyj/Home/Menu/add.html', '1', '1418646311');
INSERT INTO `xj_action_log` VALUES ('50', '10', '1', '0', 'Menu', '151', '操作url：/tyj/Home/Menu/add.html', '1', '1418646368');
INSERT INTO `xj_action_log` VALUES ('51', '10', '1', '0', 'Menu', '152', '操作url：/tyj/Home/Menu/add.html', '1', '1418646841');
INSERT INTO `xj_action_log` VALUES ('52', '1', '1', '0', 'member', '1', '李浩在2014-12-16 10:23登录了后台', '1', '1418696606');
INSERT INTO `xj_action_log` VALUES ('53', '1', '1', '0', 'member', '1', '李浩在2014-12-16 10:23登录了后台', '1', '1418696616');
INSERT INTO `xj_action_log` VALUES ('54', '7', '1', '0', 'model', '5', '操作url：/tyj/Admin/Model/update.html', '1', '1418702724');
INSERT INTO `xj_action_log` VALUES ('55', '8', '1', '0', 'attribute', '39', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418706206');
INSERT INTO `xj_action_log` VALUES ('56', '8', '1', '0', 'attribute', '39', '操作url：/tyj/Admin/Attribute/remove/id/39.html', '1', '1418708345');
INSERT INTO `xj_action_log` VALUES ('57', '8', '1', '0', 'attribute', '40', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708409');
INSERT INTO `xj_action_log` VALUES ('58', '8', '1', '0', 'attribute', '41', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708601');
INSERT INTO `xj_action_log` VALUES ('59', '8', '1', '0', 'attribute', '42', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418708645');
INSERT INTO `xj_action_log` VALUES ('60', '8', '1', '0', 'attribute', '42', '操作url：/tyj/Admin/Attribute/remove/id/42.html', '1', '1418708691');
INSERT INTO `xj_action_log` VALUES ('61', '8', '1', '0', 'attribute', '41', '操作url：/tyj/Admin/Attribute/remove/id/41.html', '1', '1418708699');
INSERT INTO `xj_action_log` VALUES ('62', '8', '1', '0', 'attribute', '40', '操作url：/tyj/Admin/Attribute/remove/id/40.html', '1', '1418708714');
INSERT INTO `xj_action_log` VALUES ('63', '8', '1', '0', 'attribute', '43', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418710689');
INSERT INTO `xj_action_log` VALUES ('64', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418711568');
INSERT INTO `xj_action_log` VALUES ('65', '8', '1', '0', 'attribute', '50', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418711609');
INSERT INTO `xj_action_log` VALUES ('66', '8', '1', '0', 'attribute', '50', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418711631');
INSERT INTO `xj_action_log` VALUES ('67', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418714595');
INSERT INTO `xj_action_log` VALUES ('68', '8', '1', '0', 'attribute', '51', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418714765');
INSERT INTO `xj_action_log` VALUES ('69', '7', '1', '0', 'model', '7', '操作url：/tyj/Admin/Model/update.html', '1', '1418719028');
INSERT INTO `xj_action_log` VALUES ('70', '7', '1', '0', 'model', '6', '操作url：/tyj/Admin/Model/update.html', '1', '1418719044');
INSERT INTO `xj_action_log` VALUES ('71', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418727884');
INSERT INTO `xj_action_log` VALUES ('72', '8', '1', '0', 'attribute', '54', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418728004');
INSERT INTO `xj_action_log` VALUES ('73', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418728445');
INSERT INTO `xj_action_log` VALUES ('74', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418728474');
INSERT INTO `xj_action_log` VALUES ('75', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:38登录了后台', '1', '1418729884');
INSERT INTO `xj_action_log` VALUES ('76', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:38登录了后台', '1', '1418729900');
INSERT INTO `xj_action_log` VALUES ('77', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:44登录了后台', '1', '1418730283');
INSERT INTO `xj_action_log` VALUES ('78', '1', '1', '0', 'member', '1', '李浩在2014-12-16 19:50登录了后台', '1', '1418730609');
INSERT INTO `xj_action_log` VALUES ('79', '8', '1', '0', 'attribute', '55', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418732002');
INSERT INTO `xj_action_log` VALUES ('80', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418734613');
INSERT INTO `xj_action_log` VALUES ('81', '7', '1', '0', 'model', '9', '操作url：/tyj/Admin/Model/update.html', '1', '1418735297');
INSERT INTO `xj_action_log` VALUES ('82', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418735678');
INSERT INTO `xj_action_log` VALUES ('83', '8', '1', '0', 'attribute', '56', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418735715');
INSERT INTO `xj_action_log` VALUES ('84', '8', '1', '0', 'attribute', '57', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418735756');
INSERT INTO `xj_action_log` VALUES ('85', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418735920');
INSERT INTO `xj_action_log` VALUES ('86', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736083');
INSERT INTO `xj_action_log` VALUES ('87', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736109');
INSERT INTO `xj_action_log` VALUES ('88', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736217');
INSERT INTO `xj_action_log` VALUES ('89', '8', '1', '0', 'attribute', '58', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418736690');
INSERT INTO `xj_action_log` VALUES ('90', '8', '1', '0', 'attribute', '59', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418736789');
INSERT INTO `xj_action_log` VALUES ('91', '7', '1', '0', 'model', '10', '操作url：/tyj/Admin/Model/update.html', '1', '1418736844');
INSERT INTO `xj_action_log` VALUES ('92', '8', '1', '0', 'attribute', '56', '操作url：/tyj/Admin/Attribute/remove/id/56.html', '1', '1418736914');
INSERT INTO `xj_action_log` VALUES ('93', '8', '1', '0', 'attribute', '60', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737432');
INSERT INTO `xj_action_log` VALUES ('94', '8', '1', '0', 'attribute', '61', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737599');
INSERT INTO `xj_action_log` VALUES ('95', '8', '1', '0', 'attribute', '62', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737615');
INSERT INTO `xj_action_log` VALUES ('96', '8', '1', '0', 'attribute', '63', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418737823');
INSERT INTO `xj_action_log` VALUES ('97', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418738823');
INSERT INTO `xj_action_log` VALUES ('98', '8', '1', '0', 'attribute', '68', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418738946');
INSERT INTO `xj_action_log` VALUES ('99', '8', '1', '0', 'attribute', '69', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418739032');
INSERT INTO `xj_action_log` VALUES ('100', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739159');
INSERT INTO `xj_action_log` VALUES ('101', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739184');
INSERT INTO `xj_action_log` VALUES ('102', '7', '1', '0', 'model', '11', '操作url：/tyj/Admin/Model/update.html', '1', '1418739205');
INSERT INTO `xj_action_log` VALUES ('103', '1', '1', '0', 'member', '1', '李浩在2014-12-17 00:20登录了后台', '1', '1418746804');
INSERT INTO `xj_action_log` VALUES ('104', '1', '1', '0', 'member', '1', '李浩在2014-12-17 12:45登录了后台', '1', '1418791537');
INSERT INTO `xj_action_log` VALUES ('105', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418802016');
INSERT INTO `xj_action_log` VALUES ('106', '8', '1', '0', 'attribute', '82', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802074');
INSERT INTO `xj_action_log` VALUES ('107', '8', '1', '0', 'attribute', '83', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802189');
INSERT INTO `xj_action_log` VALUES ('108', '8', '1', '0', 'attribute', '84', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802338');
INSERT INTO `xj_action_log` VALUES ('109', '8', '1', '0', 'attribute', '85', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802392');
INSERT INTO `xj_action_log` VALUES ('110', '8', '1', '0', 'attribute', '86', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418802915');
INSERT INTO `xj_action_log` VALUES ('111', '8', '1', '0', 'attribute', '87', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803034');
INSERT INTO `xj_action_log` VALUES ('112', '8', '1', '0', 'attribute', '88', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803183');
INSERT INTO `xj_action_log` VALUES ('113', '8', '1', '0', 'attribute', '89', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803554');
INSERT INTO `xj_action_log` VALUES ('114', '8', '1', '0', 'attribute', '90', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803597');
INSERT INTO `xj_action_log` VALUES ('115', '8', '1', '0', 'attribute', '83', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418803756');
INSERT INTO `xj_action_log` VALUES ('116', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418803993');
INSERT INTO `xj_action_log` VALUES ('117', '8', '1', '0', 'attribute', '89', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418804042');
INSERT INTO `xj_action_log` VALUES ('118', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418806200');
INSERT INTO `xj_action_log` VALUES ('119', '8', '1', '0', 'attribute', '86', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418806399');
INSERT INTO `xj_action_log` VALUES ('120', '1', '1', '0', 'member', '1', '李浩在2014-12-17 20:47登录了后台', '1', '1418820422');
INSERT INTO `xj_action_log` VALUES ('121', '7', '1', '0', 'model', '19', '操作url：/tyj/Admin/Model/update.html', '1', '1418820444');
INSERT INTO `xj_action_log` VALUES ('122', '1', '1', '0', 'member', '1', '李浩在2014-12-18 09:20登录了后台', '1', '1418865647');
INSERT INTO `xj_action_log` VALUES ('123', '8', '1', '0', 'attribute', '86', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418865687');
INSERT INTO `xj_action_log` VALUES ('124', '8', '1', '0', 'attribute', '89', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418865962');
INSERT INTO `xj_action_log` VALUES ('125', '8', '1', '0', 'attribute', '88', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418866062');
INSERT INTO `xj_action_log` VALUES ('126', '8', '1', '0', 'attribute', '91', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418866472');
INSERT INTO `xj_action_log` VALUES ('127', '8', '1', '0', 'attribute', '91', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418866509');
INSERT INTO `xj_action_log` VALUES ('128', '10', '1', '0', 'Menu', '153', '操作url：/tyj/Admin/Menu/add.html', '1', '1418876502');
INSERT INTO `xj_action_log` VALUES ('129', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418882445');
INSERT INTO `xj_action_log` VALUES ('130', '8', '1', '0', 'attribute', '92', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418882734');
INSERT INTO `xj_action_log` VALUES ('131', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418882805');
INSERT INTO `xj_action_log` VALUES ('132', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418882912');
INSERT INTO `xj_action_log` VALUES ('133', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418883954');
INSERT INTO `xj_action_log` VALUES ('134', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418885351');
INSERT INTO `xj_action_log` VALUES ('135', '8', '1', '0', 'attribute', '92', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418887559');
INSERT INTO `xj_action_log` VALUES ('136', '8', '1', '0', 'attribute', '92', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418887578');
INSERT INTO `xj_action_log` VALUES ('137', '7', '1', '0', 'model', '18', '操作url：/tyj/Admin/Model/update.html', '1', '1418889357');
INSERT INTO `xj_action_log` VALUES ('138', '8', '1', '0', 'attribute', '87', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418890382');
INSERT INTO `xj_action_log` VALUES ('139', '8', '1', '0', 'attribute', '82', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418891555');
INSERT INTO `xj_action_log` VALUES ('140', '1', '1', '0', 'member', '1', '李浩在2014-12-18 23:11登录了后台', '1', '1418915514');
INSERT INTO `xj_action_log` VALUES ('141', '1', '1', '0', 'member', '1', '李浩在2014-12-18 23:12登录了后台', '1', '1418915571');
INSERT INTO `xj_action_log` VALUES ('142', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:13登录了后台', '1', '1418915632');
INSERT INTO `xj_action_log` VALUES ('143', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:14登录了后台', '1', '1418915643');
INSERT INTO `xj_action_log` VALUES ('144', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:15登录了后台', '1', '1418915708');
INSERT INTO `xj_action_log` VALUES ('145', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:17登录了后台', '1', '1418915875');
INSERT INTO `xj_action_log` VALUES ('146', '1', '1', '0', 'member', '1', '李浩在2014-12-18 23:19登录了后台', '1', '1418915976');
INSERT INTO `xj_action_log` VALUES ('147', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:21登录了后台', '1', '1418916080');
INSERT INTO `xj_action_log` VALUES ('148', '1', '1', '0', 'member', '1', '李浩在2014-12-18 23:26登录了后台', '1', '1418916419');
INSERT INTO `xj_action_log` VALUES ('149', '1', '2', '0', 'member', '2', 'lihao在2014-12-18 23:28登录了后台', '1', '1418916497');
INSERT INTO `xj_action_log` VALUES ('150', '1', '1', '0', 'member', '1', '李浩在2014-12-19 10:01登录了后台', '1', '1418954484');
INSERT INTO `xj_action_log` VALUES ('151', '8', '1', '0', 'attribute', '104', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418954725');
INSERT INTO `xj_action_log` VALUES ('152', '8', '1', '0', 'attribute', '105', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418954751');
INSERT INTO `xj_action_log` VALUES ('153', '8', '1', '0', 'attribute', '106', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418954824');
INSERT INTO `xj_action_log` VALUES ('154', '8', '1', '0', 'attribute', '107', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418955083');
INSERT INTO `xj_action_log` VALUES ('155', '8', '1', '0', 'attribute', '108', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418955236');
INSERT INTO `xj_action_log` VALUES ('156', '8', '1', '0', 'attribute', '107', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418955266');
INSERT INTO `xj_action_log` VALUES ('157', '7', '1', '0', 'model', '20', '操作url：/tyj/Admin/Model/update.html', '1', '1418955550');
INSERT INTO `xj_action_log` VALUES ('158', '8', '1', '0', 'attribute', '107', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418956979');
INSERT INTO `xj_action_log` VALUES ('159', '8', '1', '0', 'attribute', '96', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418958270');
INSERT INTO `xj_action_log` VALUES ('160', '8', '1', '0', 'attribute', '109', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418960454');
INSERT INTO `xj_action_log` VALUES ('161', '8', '1', '0', 'attribute', '109', '操作url：/tyj/Admin/Attribute/remove/id/109.html', '1', '1418960552');
INSERT INTO `xj_action_log` VALUES ('162', '7', '1', '0', 'model', '20', '操作url：/tyj/Admin/Model/update.html', '1', '1418960866');
INSERT INTO `xj_action_log` VALUES ('163', '8', '1', '0', 'attribute', '105', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418960963');
INSERT INTO `xj_action_log` VALUES ('164', '8', '1', '0', 'attribute', '104', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418960973');
INSERT INTO `xj_action_log` VALUES ('165', '8', '1', '0', 'attribute', '108', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418961765');
INSERT INTO `xj_action_log` VALUES ('166', '8', '1', '0', 'attribute', '108', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418962194');
INSERT INTO `xj_action_log` VALUES ('167', '7', '1', '0', 'model', '20', '操作url：/tyj/Admin/Model/update.html', '1', '1418965496');
INSERT INTO `xj_action_log` VALUES ('168', '7', '1', '0', 'model', '21', '操作url：/tyj/Admin/Model/update.html', '1', '1418965935');
INSERT INTO `xj_action_log` VALUES ('169', '8', '1', '0', 'attribute', '121', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418966043');
INSERT INTO `xj_action_log` VALUES ('170', '8', '1', '0', 'attribute', '121', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418966067');
INSERT INTO `xj_action_log` VALUES ('171', '8', '1', '0', 'attribute', '85', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418966250');
INSERT INTO `xj_action_log` VALUES ('172', '8', '1', '0', 'attribute', '113', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418966293');
INSERT INTO `xj_action_log` VALUES ('173', '10', '1', '0', 'Menu', '151', '操作url：/tyj/Admin/Menu/edit.html', '1', '1418966364');
INSERT INTO `xj_action_log` VALUES ('174', '7', '1', '0', 'model', '21', '操作url：/tyj/Admin/Model/update.html', '1', '1418966407');
INSERT INTO `xj_action_log` VALUES ('175', '8', '1', '0', 'attribute', '121', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418966462');
INSERT INTO `xj_action_log` VALUES ('176', '8', '1', '0', 'attribute', '105', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418974340');
INSERT INTO `xj_action_log` VALUES ('177', '8', '1', '0', 'attribute', '104', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418974369');
INSERT INTO `xj_action_log` VALUES ('178', '8', '1', '0', 'attribute', '105', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418976968');
INSERT INTO `xj_action_log` VALUES ('179', '8', '1', '0', 'attribute', '104', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418976981');
INSERT INTO `xj_action_log` VALUES ('180', '8', '1', '0', 'attribute', '133', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418978785');
INSERT INTO `xj_action_log` VALUES ('181', '7', '1', '0', 'model', '22', '操作url：/tyj/Admin/Model/update.html', '1', '1418979078');
INSERT INTO `xj_action_log` VALUES ('182', '8', '1', '0', 'attribute', '133', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418979125');
INSERT INTO `xj_action_log` VALUES ('183', '7', '1', '0', 'model', '22', '操作url：/tyj/Admin/Model/update.html', '1', '1418979339');
INSERT INTO `xj_action_log` VALUES ('184', '8', '1', '0', 'attribute', '134', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418979726');
INSERT INTO `xj_action_log` VALUES ('185', '8', '1', '0', 'attribute', '98', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418979835');
INSERT INTO `xj_action_log` VALUES ('186', '8', '1', '0', 'attribute', '135', '操作url：/tyj/Admin/Attribute/update.html', '1', '1418986871');
INSERT INTO `xj_action_log` VALUES ('187', '10', '1', '0', 'Menu', '154', '操作url：/tyj/Admin/Menu/add.html', '1', '1418994326');
INSERT INTO `xj_action_log` VALUES ('188', '10', '1', '0', 'Menu', '155', '操作url：/tyj/Admin/Sports/add.html', '1', '1418994487');
INSERT INTO `xj_action_log` VALUES ('189', '10', '1', '0', 'Menu', '4', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081085');
INSERT INTO `xj_action_log` VALUES ('190', '10', '1', '0', 'Menu', '156', '操作url：/tyj/Admin/Menu/add.html', '1', '1419081301');
INSERT INTO `xj_action_log` VALUES ('191', '10', '1', '0', 'Menu', '157', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081523');
INSERT INTO `xj_action_log` VALUES ('192', '10', '1', '0', 'Menu', '158', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081531');
INSERT INTO `xj_action_log` VALUES ('193', '10', '1', '0', 'Menu', '159', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081537');
INSERT INTO `xj_action_log` VALUES ('194', '10', '1', '0', 'Menu', '160', '操作url：/tyj/Admin/Menu/add.html', '1', '1419081703');
INSERT INTO `xj_action_log` VALUES ('195', '10', '1', '0', 'Menu', '157', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081986');
INSERT INTO `xj_action_log` VALUES ('196', '10', '1', '0', 'Menu', '158', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419081996');
INSERT INTO `xj_action_log` VALUES ('197', '10', '1', '0', 'Menu', '159', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419082011');
INSERT INTO `xj_action_log` VALUES ('198', '10', '1', '0', 'Menu', '161', '操作url：/tyj/Admin/Menu/add.html', '1', '1419082403');
INSERT INTO `xj_action_log` VALUES ('199', '10', '1', '0', 'Menu', '154', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419082423');
INSERT INTO `xj_action_log` VALUES ('200', '10', '1', '0', 'Menu', '152', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419082451');
INSERT INTO `xj_action_log` VALUES ('201', '10', '1', '0', 'Menu', '154', '操作url：/tyj/Admin/Menu/edit.html', '1', '1419082475');

-- -----------------------------
-- Table structure for `xj_article`
-- -----------------------------
DROP TABLE IF EXISTS `xj_article`;
CREATE TABLE `xj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `title_color` char(10) NOT NULL DEFAULT '#555' COMMENT '标题颜色',
  `list_color` char(10) NOT NULL DEFAULT '#555' COMMENT '列表页面显示颜色',
  `content` text NOT NULL COMMENT '文章内容',
  `is_up` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `position` varchar(100) NOT NULL COMMENT '推荐位',
  `cover` int(10) unsigned NOT NULL COMMENT '封面',
  `extend` text NOT NULL COMMENT '扩展统计字段',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `xj_article`
-- -----------------------------
INSERT INTO `xj_article` VALUES ('1', '相关规定', '1', '16', '', '', '-28800', '0', '1418961366', '1418979896', '', '1', '#555', '#555', '&lt;p class=&quot;title&quot; style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 15px; list-style: none; border-bottom-color: rgb(240, 240, 240); border-bottom-width: 1px; border-bottom-style: solid; overflow: hidden; text-align: center; color: rgb(8, 103, 90); font-size: 20px; font-weight: bold; line-height: 26px; font-family: 微软雅黑; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;关于印发《运动员行踪信息管理规定》的通知&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;strong style=&quot;color: rgb(51, 51, 51); font-family: 微软雅黑; font-size: 20px; line-height: 28px; text-align: center; margin: 0px; padding: 0px;&quot;&gt;运动员行踪信息管理规定&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第一章 总则&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第一条&lt;/strong&gt;&amp;nbsp;为有效开展赛外兴奋剂检查，确保对运动员实施准确有效的赛外兴奋剂检查,根据国务院《反兴奋剂条例》及国家体育总局有关规定，参照《世界反兴奋剂条例》和《兴奋剂检查国际标准》有关条款，制定本规定。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第二条&lt;/strong&gt;&amp;nbsp;本规定所称运动员是指在兴奋剂注册检查库库内，需申报行踪信息的运动员。运动员应当按照相关要求申报行踪信息，不在兴奋剂注册检查库之内或经调整被撤出的运动员无需申报行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第二章 兴奋剂注册检查库&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第三条&lt;/strong&gt;&amp;nbsp;兴奋剂注册检查库是指国家体育总局反兴奋剂中心（以下简称反兴奋剂中心）根据项目特点、重大赛事成绩、运动员国际国内年度排名、国际单项联合会注册检查库及禁赛期运动员等因素，建立的用于实施兴奋剂检查的高水平运动员注册名单。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第四条&lt;/strong&gt;&amp;nbsp;兴奋剂注册检查库在反兴奋剂中心官方网站上公布，每年至少公布一次，并由反兴奋剂中心通过公函的方式通知各运动员管理单位。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第五条&lt;/strong&gt;&amp;nbsp;反兴奋剂中心依据运动员退役、禁赛、复出及运动成绩变化等因素，适时调整兴奋剂注册检查库。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第六条&lt;/strong&gt;&amp;nbsp;新的兴奋剂注册检查库名单下发前，原兴奋剂注册检查库一直有效，无论是否跨年，运动员均须按照相关要求申报行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第七条&lt;/strong&gt;&amp;nbsp;运动员若决定退役（自2009年起，凡被列入兴奋剂注册检查库内的运动员，无论其是否在当前国家注册检查库中），应向所属全国性单项体育协会和反兴奋剂中心提交运动员本人签名并加盖单位公章的《运动员退役报告》(附件1)，该运动员将被从兴奋剂注册检查库中撤出，不再需要申报行踪信息，并且不再列入反兴奋剂中心的兴奋剂检查计划中。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第八条&lt;/strong&gt;&amp;nbsp;已退役的运动员（自2009年起，凡被列入兴奋剂注册检查库内的运动员）复出参赛，需提前6个月（自运动员重新上报行踪信息之日起计算）向反兴奋剂中心和所属全国性单项体育协会提交《退役运动员复出申请报告》（附件2），申报行踪信息并接受赛外检查。运动员未经批准违规参赛的，应按规定做出相应处罚。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第九条&lt;/strong&gt;&amp;nbsp;运动员变更注册单位，原注册单位和现注册单位均应书面通知反兴奋剂中心。该运动员变更期间（即暂无注册单位）及新单位完成注册后，应继续申报行踪信息。如运动员中断行踪信息申报，作为其恢复参赛资格的条件，其至少应在重新注册（参赛）前3个月（中断时间超出3个月的按照实际天数计算）申报行踪信息，并接受赛外检查。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十条&lt;/strong&gt;&amp;nbsp;处于禁赛期的运动员，必须在禁赛期间随时接受反兴奋剂中心组织实施的赛外检查，并且根据要求提供准确的行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第三章 行踪信息申报要求&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十一条&lt;/strong&gt;&amp;nbsp;运动员本人对及时、准确填报行踪信息，并确保其能在申报的行踪信息所指明的地点接受兴奋剂检查负责。运动员管理单位需告知运动员相关责任和义务，并协助其按要求完成行踪信息申报。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十二条&lt;/strong&gt;&amp;nbsp;运动员应当按照规定及时、准确填报个人《运动员行踪信息申报表》（附件3），每季度最后一个月的20日前上报下一季度行踪信息，即第一、二、三、四季度行踪信息应于上年12月20日、当年3月20日、6月20日、9月20日前上报。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十三条&lt;/strong&gt;&amp;nbsp;新增兴奋剂注册检查库运动员应当于名单下发后10个工作日内申报当前季度行踪信息，之后按照第十三条规定申报季度行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十四条&lt;/strong&gt;&amp;nbsp;运动员行踪信息申报需包括以下信息：&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（一）运动员完整的通信地址；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（二）运动员下季度每天的住址，包括家、宿舍及宾馆等，需具体到门牌号、房间号；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（三）运动员下季度每天从事规律性活动的具体地址及时间安排，包括训练、培训等；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（四）运动员下季度的比赛日程，包括比赛名称、比赛地点、比赛时间等；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（五）运动员下季度可在每天6点至23点之间任意60分钟的建议检查时间及特定检查地点；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（六）休假、旅途的详细信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十五条&lt;/strong&gt;&amp;nbsp;当行踪信息将发生变更时，运动员应当在变更前48小时填报变更后的《运动员行踪信息申报表》。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十六条&lt;/strong&gt;&amp;nbsp;运动员如有下述未按照相关要求申报其行踪信息，可能会导致相关处罚：&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（一）如运动员未填报任何行踪信息(含未在规定时间内填报)、上报的行踪信息里未包含必需的信息、或者填报的行踪信息不准确或不详细；以及依据运动员行踪信息在一小时建议检查时段外实施检查时未查到运动员的，运动员将被判定为填报失败；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（二）如运动员未能在指定的一小时建议检查时段内在指定的地点接受兴奋剂检查，运动员将被判定为错过检查；&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;（三）运动员行踪信息填报失败或错过检查将按照国家体育总局相关规定给予处罚。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;运动员在填报的行踪信息中提供欺骗性信息，或其他恶劣情况，将根据其具体情节，按照逃避兴奋剂检查、篡改或企图篡改兴奋剂检查结果等违反反兴奋剂规则行为进行判定，并按照《关于严格禁止在体育运动中使用兴奋剂行为的规定（暂行）》（中华人民共和国国家体育总局令第1号）给予处罚。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第四章 附 则&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十七条&lt;/strong&gt;&amp;nbsp;为加强参加奥运会、亚运会等综合性运动会中国代表团运动员的监控和检查，反兴奋剂中心将根据赛事安排建立运动会兴奋剂注册检查库，代表团所有运动员均为库内人员，需按照反兴奋剂中心专门下发的文件规定申报其行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;&lt;strong style=&quot;margin: 0px; padding: 0px;&quot;&gt;第十九条&lt;/strong&gt;&amp;nbsp;针对参加全运会、城运会且不在兴奋剂注册检查库内的运动员，反兴奋剂中心将根据需要建立临时兴奋剂注册检查库，库内运动员需按照反兴奋剂中心专门下发的文件规定申报其行踪信息。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; margin-bottom: 0px; padding: 5px 0px 0px; list-style: none; color: rgb(51, 51, 51); font-family: 微软雅黑; line-height: 28px; white-space: normal; background-color: rgb(255, 255, 255);&quot;&gt;第二十条 本规定自2011年7月15日起实施。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '1', '1,3', '10', '');
INSERT INTO `xj_article` VALUES ('2', '申报流程', '1', '17', '', '', '-28800', '0', '1418962132', '1418979770', '', '1', '#f83a22', '#ac725e', '&lt;p&gt;申报流程&lt;/p&gt;', '0', '1,2,3', '0', '');
INSERT INTO `xj_article` VALUES ('3', '运动员的自我修养', '1', '13', '', '', '-28800', '0', '1418977541', '1418977689', '', '1', '#42d692', '#ac725e', '&lt;p&gt;&lt;img src=&quot;/tyj/Uploads/editor/image/20141219/5493e07fb73fe.png&quot; title=&quot;5493e07fb73fe.png&quot; alt=&quot;屏幕快照 2014-12-17 下午8.03.50.png&quot; width=&quot;166&quot; height=&quot;175&quot; style=&quot;width: 166px; height: 175px;&quot;/&gt;&lt;/p&gt;&lt;p&gt;大大&lt;/p&gt;&lt;p&gt;撒旦阿萨德&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;http://img.baidu.com/hi/jx2/j_0013.gif&quot;/&gt;&lt;img src=&quot;http://img.baidu.com/hi/jx2/j_0015.gif&quot;/&gt;&lt;img src=&quot;http://img.baidu.com/hi/jx2/j_0069.gif&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;line-height: 16px;&quot;&gt;&lt;img style=&quot;vertical-align: middle; margin-right: 2px;&quot; src=&quot;http://localhost/tyj/Public/vendor/ueditor/dialogs/attachment/fileTypeImages/icon_doc.gif&quot;/&gt;&lt;a href=&quot;/tyj/Uploads/editor/file/20141219/5493e0dc091a3.doc&quot; target=&quot;_self&quot; title=&quot;大大说的&quot; textvalue=&quot;性能测试.doxc.doc&quot;&gt;性能测试.doxc.doc&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '1', '1', '0', '');

-- -----------------------------
-- Table structure for `xj_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `xj_attribute`;
CREATE TABLE `xj_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  `validate_condition` tinyint(1) NOT NULL DEFAULT '0' COMMENT '验证条件',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `xj_attribute`
-- -----------------------------
INSERT INTO `xj_attribute` VALUES ('82', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('83', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('84', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('85', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '18', '0', '1', '1418966250', '1418802392', '0,255', '3', '', 'length', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('86', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('87', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写则代表永久有效', '1', '', '18', '0', '1', '1418890382', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('88', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '18', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('89', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '18', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('90', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('91', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '18', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('92', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '18', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('93', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '20', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('94', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('95', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('96', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '20', '0', '1', '1418958271', '1418802392', '0,255', '3', '长度不能超过255个字符', 'length', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('97', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '20', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('98', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写或者显示1970-01-01则代表永久有效', '1', '', '20', '0', '1', '1418979835', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('99', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '20', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('100', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '20', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('101', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('102', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '20', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('103', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '20', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('104', 'title_color', '标题颜色', 'char(10)  NOT NULL', 'color', '\'#555\'', '默认值代表不设置', '1', '', '20', '0', '1', '1418976981', '1418954725', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('105', 'list_color', '列表页面显示颜色', 'char(10)  NOT NULL', 'color', '\'#555\'', '默认值代表不设置', '1', '', '20', '0', '1', '1418976968', '1418954751', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('106', 'content', '文章内容', 'text NOT NULL', 'editor', '', '', '1', '', '20', '1', '1', '1418954824', '1418954824', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('107', 'is_up', '是否置顶', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '20', '0', '1', '1418956979', '1418955083', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('108', 'position', '推荐位', 'varchar(100) NOT NULL', 'checkbox', '', '', '1', '[DOCUMENT_POSITION]', '20', '0', '1', '1418962194', '1418955236', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('131', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '22', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('130', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('128', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '22', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('127', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写则代表永久有效', '1', '', '22', '0', '1', '1418890382', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('126', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('125', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '22', '0', '1', '1418966250', '1418802392', '0,255', '3', '', 'length', '', '3', 'function', '2');
INSERT INTO `xj_attribute` VALUES ('124', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('123', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('122', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('129', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '22', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('132', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '22', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('133', 'file', '文件', 'int(10) UNSIGNED NOT NULL', 'file', '', '', '1', '', '22', '1', '1', '1418979125', '1418978785', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('134', 'cover', '封面', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '20', '0', '1', '1418979727', '1418979727', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `xj_attribute` VALUES ('135', 'extend', '扩展统计字段', 'text NOT NULL', 'textarea', '', '', '0', '', '20', '0', '1', '1418986871', '1418986871', '', '3', '', 'regex', '', '3', 'function', '0');

-- -----------------------------
-- Table structure for `xj_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_extend`;
CREATE TABLE `xj_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `xj_auth_extend`
-- -----------------------------
INSERT INTO `xj_auth_extend` VALUES ('3', '2', '1');
INSERT INTO `xj_auth_extend` VALUES ('3', '3', '1');
INSERT INTO `xj_auth_extend` VALUES ('3', '4', '1');
INSERT INTO `xj_auth_extend` VALUES ('3', '7', '1');
INSERT INTO `xj_auth_extend` VALUES ('3', '8', '1');
INSERT INTO `xj_auth_extend` VALUES ('3', '9', '1');

-- -----------------------------
-- Table structure for `xj_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group`;
CREATE TABLE `xj_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group`
-- -----------------------------
INSERT INTO `xj_auth_group` VALUES ('3', 'admin', '1', '测试', '测试', '1', '280,281,291');
INSERT INTO `xj_auth_group` VALUES ('4', 'admin', '1', '随即', '少', '1', '268,271,277,280,281,288');

-- -----------------------------
-- Table structure for `xj_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_group_access`;
CREATE TABLE `xj_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_group_access`
-- -----------------------------
INSERT INTO `xj_auth_group_access` VALUES ('2', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '3');
INSERT INTO `xj_auth_group_access` VALUES ('3', '4');

-- -----------------------------
-- Table structure for `xj_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `xj_auth_rule`;
CREATE TABLE `xj_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=292 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_auth_rule`
-- -----------------------------
INSERT INTO `xj_auth_rule` VALUES ('245', 'admin', '1', 'Home/menu/edit', '编辑', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('246', 'admin', '2', 'Home/Index/index', '主页', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('247', 'admin', '1', 'Home/user/index', '用户信息', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('248', 'admin', '2', 'Home/Public/index', '系统', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('249', 'admin', '1', 'Home/user/action', '用户行为', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('250', 'admin', '1', 'Home/authManager/index', '权限管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('251', 'admin', '1', 'Home/action/actionlog', '行为日志', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('252', 'admin', '1', 'Home/user/updatePassword', '修改密码', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('253', 'admin', '1', 'Home/user/updateNickname', '修改昵称', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('254', 'admin', '1', 'Home/a/b', 'cdshi', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('255', 'admin', '1', 'Home/Athlete/index', '运动员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('256', 'admin', '1', 'Home/Coach/index', '教练员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('257', 'admin', '1', 'Home/Judge/index', '裁判员管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('258', 'admin', '1', 'Home/Equipe/index', '运动队管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('259', 'admin', '1', 'Home/menu/index', '菜单管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('260', 'admin', '1', 'Home/config/group', '网站设置', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('261', 'admin', '1', 'Home/menu/add', '新增', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('262', 'admin', '1', 'Home/menu/del', '删除', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('263', 'admin', '1', 'Home/menu/import', '导入', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('264', 'admin', '1', 'Home/database/exportIndex', '备份数据库', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('265', 'admin', '1', 'Home/database/importIndex', '还原数据库', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('266', 'admin', '1', 'Home/config/index', '配置管理', '-1', '');
INSERT INTO `xj_auth_rule` VALUES ('267', 'admin', '1', 'Admin/menu/add', '新增', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('268', 'admin', '1', 'Admin/menu/del', '删除', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('269', 'admin', '1', 'Admin/menu/import', '导入', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('270', 'admin', '1', 'Admin/menu/edit', '编辑', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('271', 'admin', '1', 'Admin/user/index', '用户信息', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('272', 'admin', '1', 'Admin/user/action', '用户行为', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('273', 'admin', '1', 'Admin/authManager/index', '权限管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('274', 'admin', '1', 'Admin/action/actionlog', '行为日志', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('275', 'admin', '1', 'Admin/user/updatePassword', '修改密码', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('276', 'admin', '1', 'Admin/user/updateNickname', '修改昵称', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('277', 'admin', '1', 'Admin/a/b', 'cdshi', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('278', 'admin', '1', 'Admin/config/group', '网站设置', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('279', 'admin', '1', 'Admin/config/index', '配置管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('280', 'admin', '2', 'Admin/Public/index', '系统', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Category/index', '栏目管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('282', 'admin', '1', 'Admin/model/index', '模型管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('283', 'admin', '2', 'Admin/Index/index', '主页', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('284', 'admin', '1', 'Admin/Athlete/index', '运动员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('285', 'admin', '1', 'Admin/Coach/index', '教练员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('286', 'admin', '1', 'Admin/Judge/index', '裁判员管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('287', 'admin', '1', 'Admin/Equipe/index', '运动队管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('288', 'admin', '1', 'Admin/menu/index', '菜单管理', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('289', 'admin', '1', 'Admin/database/exportIndex', '备份数据库', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('290', 'admin', '1', 'Admin/database/importIndex', '还原数据库', '1', '');
INSERT INTO `xj_auth_rule` VALUES ('291', 'admin', '1', 'Admin/content/index', '内容管理', '1', '');

-- -----------------------------
-- Table structure for `xj_base_article`
-- -----------------------------
DROP TABLE IF EXISTS `xj_base_article`;
CREATE TABLE `xj_base_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `xj_config`
-- -----------------------------
DROP TABLE IF EXISTS `xj_config`;
CREATE TABLE `xj_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_config`
-- -----------------------------
INSERT INTO `xj_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '天津市体育局训竞服务网络平台', '1');
INSERT INTO `xj_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '', '2');
INSERT INTO `xj_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '', '9');
INSERT INTO `xj_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '6');
INSERT INTO `xj_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '14');
INSERT INTO `xj_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '15');
INSERT INTO `xj_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位', '1379053380', '1418962223', '1', '1:列表页推荐\r\n2:频道页推荐\r\n3:网站首页推荐', '5');
INSERT INTO `xj_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '7');
INSERT INTO `xj_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '16');
INSERT INTO `xj_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '10');
INSERT INTO `xj_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '11');
INSERT INTO `xj_config` VALUES ('40', 'TEMP_PATH', '2', '前台模版路径', '2', '', '内容显示的模版路径', '1418650622', '1418651066', '1', './Template', '0');
INSERT INTO `xj_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '20');
INSERT INTO `xj_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '21');
INSERT INTO `xj_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '4');
INSERT INTO `xj_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '17');
INSERT INTO `xj_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '8');
INSERT INTO `xj_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '18');
INSERT INTO `xj_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '22');
INSERT INTO `xj_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '24');
INSERT INTO `xj_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1418916067', '1', '1:index/index\r\n2:Index/verify\r\n3:file/upload\r\n4:file/download\r\n5:user/updatePassword\r\n6:user/updateNickname\r\n7:user/submitPassword\r\n8:user/submitNickname\r\n9:file/uploadpicture', '3');
INSERT INTO `xj_config` VALUES ('41', 'SYSTEM_COLOR', '3', '颜色配置', '0', '', '通用颜色', '1418973661', '1418976664', '1', '#555\r\n#ac725e\r\n#d06b64\r\n#f83a22\r\n#fa573c\r\n#ff7537\r\n#ffad46\r\n#42d692\r\n#16a765\r\n#7bd148\r\n#b3dc6c\r\n#fbe983\r\n#fad165\r\n#92e1c0\r\n#9fe1e7\r\n#9fc6e7\r\n#4986e7\r\n#9a9cff\r\n#b99aff\r\n#c2c2c2\r\n#cabdbf\r\n#cca6ac\r\n#f691b2\r\n#cd74e6\r\n#a47ae2\r\n\r\n', '0');
INSERT INTO `xj_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '12');
INSERT INTO `xj_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '23');
INSERT INTO `xj_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '25');
INSERT INTO `xj_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '13');
INSERT INTO `xj_config` VALUES ('42', 'SPORT_GROUP', '3', '项目层级的组别名称', '0', '', '', '1419003723', '1419003723', '1', '0:项目\r\n1:分项\r\n2:组别\r\n3:小项', '0');

-- -----------------------------
-- Table structure for `xj_document`
-- -----------------------------
DROP TABLE IF EXISTS `xj_document`;
CREATE TABLE `xj_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `xj_document`
-- -----------------------------
INSERT INTO `xj_document` VALUES ('1', '我是李浩', '12');

-- -----------------------------
-- Table structure for `xj_download`
-- -----------------------------
DROP TABLE IF EXISTS `xj_download`;
CREATE TABLE `xj_download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `file` int(10) unsigned NOT NULL COMMENT '文件',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `xj_download`
-- -----------------------------
INSERT INTO `xj_download` VALUES ('1', '运动员信息', '1', '18', '2014年运动员的信息', '', '0', '0', '1418979431', '1418979431', '', '1', '13');
INSERT INTO `xj_download` VALUES ('2', '第二条新闻', '1', '18', '呵呵', '', '0', '0', '1418979534', '1418979534', '', '1', '13');

-- -----------------------------
-- Table structure for `xj_exlink`
-- -----------------------------
DROP TABLE IF EXISTS `xj_exlink`;
CREATE TABLE `xj_exlink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_id` int(10) NOT NULL COMMENT '图片外键',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `url` varchar(200) NOT NULL COMMENT 'url链接',
  `sort` int(11) NOT NULL COMMENT '排序',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_file`
-- -----------------------------
DROP TABLE IF EXISTS `xj_file`;
CREATE TABLE `xj_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `xj_file`
-- -----------------------------
INSERT INTO `xj_file` VALUES ('12', '屏幕快照 2014-12-17 下午8.03.50.png', '5493b68e35017.png', '2014-12-19/', 'png', 'image/png', '237017', '4cacbb3d8c186b4092c625b6337b83b1', '0c4383749ef8ae4fa4c68374939c14efb707e525', '0', '1418966670');
INSERT INTO `xj_file` VALUES ('11', 'article.model', '548ee0cd838ad.model', '2014-12-15/', 'model', 'text/plain', '208', '08a4b8435d1412147c870104a8e34bf8', '118b6e9b4572c145e7bc51866a307669539eafde', '0', '1418649805');
INSERT INTO `xj_file` VALUES ('10', '546972193c65c.model', '548eddb58b4ee.model', '2014-12-15/', 'model', 'text/plain', '221', '38b086ec6301e686b9124c736c60df7b', 'f0c04950ab0bf45998051f97b3974a0892ab051e', '0', '1418649013');
INSERT INTO `xj_file` VALUES ('13', '性能测试.doxc.doc', '5493b69fd56e8.doc', '2014-12-19/', 'doc', 'application/msword', '134144', '9e73d31b4fad35ecada6bda4ca87ef41', 'ba68d260f496c95fdbe402e73ee9457c6210ee01', '0', '1418966687');

-- -----------------------------
-- Table structure for `xj_link_group`
-- -----------------------------
DROP TABLE IF EXISTS `xj_link_group`;
CREATE TABLE `xj_link_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '0表示可以有文字或者图片，1表示只能是文字，3表示必须有图片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_member`
-- -----------------------------
DROP TABLE IF EXISTS `xj_member`;
CREATE TABLE `xj_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(40) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `login_times` int(11) DEFAULT '0',
  `nickname` char(40) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0代表管理员,1代表运动员,2代表教练,3代表裁判',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `xj_member`
-- -----------------------------
INSERT INTO `xj_member` VALUES ('1', 'admin', 'f61dab13255ee02ee71569aafb1b11653b007cbe', '953445224@qq.com', '', '1415582883', '0', '1418954484', '0', '1415582883', '1', '62', '李浩', '0');
INSERT INTO `xj_member` VALUES ('2', 'lihao', 'f61dab13255ee02ee71569aafb1b11653b007cbe', '953445223@qq.com', '', '1418455631', '0', '1418916497', '0', '1418491475', '1', '31', 'lihao', '0');
INSERT INTO `xj_member` VALUES ('3', 'lihao123', 'f61dab13255ee02ee71569aafb1b11653b007cbe', '953445222@qq.com', '', '1418455805', '0', '0', '0', '1418455805', '1', '0', 'lihao123', '0');

-- -----------------------------
-- Table structure for `xj_menu`
-- -----------------------------
DROP TABLE IF EXISTS `xj_menu`;
CREATE TABLE `xj_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_menu`
-- -----------------------------
INSERT INTO `xj_menu` VALUES ('134', '新增', '128', '0', 'menu/add', '0', '新增菜单dasdasd', '', '0');
INSERT INTO `xj_menu` VALUES ('135', '删除', '128', '0', 'menu/del', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('136', '导入', '128', '0', 'menu/import', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('137', '编辑', '128', '0', 'menu/edit', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('138', '主页', '0', '1', 'Index/index', '0', '这个是主页', '', '0');
INSERT INTO `xj_menu` VALUES ('141', '用户信息', '140', '0', 'user/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('140', '用户', '0', '4', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('142', '用户行为', '140', '0', 'user/action', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('143', '权限管理', '140', '0', 'authManager/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('144', '行为日志', '140', '0', 'action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `xj_menu` VALUES ('145', '修改密码', '140', '0', 'user/updatePassword', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('146', '修改昵称', '140', '0', 'user/updateNickname', '1', '', '', '0');
INSERT INTO `xj_menu` VALUES ('147', 'cdshi', '141', '0', 'a/b', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('7', '运动员管理', '2', '1', 'Athlete/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('4', '人员', '0', '3', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('125', '教练员管理', '2', '2', 'Coach/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('126', '裁判员管理', '2', '3', 'Judge/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('127', '运动队管理', '2', '4', 'Equipe/index', '0', '', '人员组织管理', '0');
INSERT INTO `xj_menu` VALUES ('128', '菜单管理', '6', '6', 'menu/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('129', '备份数据库', '6', '6', 'database/exportIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('130', '还原数据库', '6', '6', 'database/importIndex', '0', '', '数据备份', '0');
INSERT INTO `xj_menu` VALUES ('6', '系统', '0', '5', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('148', '网站设置', '6', '0', 'config/group', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('149', '配置管理', '6', '0', 'config/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('150', '内容', '0', '2', 'Public/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('151', '分类管理', '150', '0', 'Category/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('152', '模型管理', '6', '0', 'model/index', '0', '', '系统设置', '0');
INSERT INTO `xj_menu` VALUES ('153', '内容管理', '150', '0', 'content/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('154', '运动项目管理', '6', '0', 'sports/index', '0', '', '运动项目', '0');
INSERT INTO `xj_menu` VALUES ('156', '审核用户', '140', '0', 'userVerify/index', '0', '', '用户管理', '0');
INSERT INTO `xj_menu` VALUES ('157', '运动员管理', '4', '0', 'person/athlete', '0', '', '人员管理', '0');
INSERT INTO `xj_menu` VALUES ('158', '教练员管理', '4', '0', 'person/coach', '0', '', '人员管理', '0');
INSERT INTO `xj_menu` VALUES ('159', '裁判员管理', '4', '0', 'person/referee', '0', '', '人员管理', '0');
INSERT INTO `xj_menu` VALUES ('160', '运动队管理', '4', '0', 'sportsteam/index', '0', '', '', '0');
INSERT INTO `xj_menu` VALUES ('161', '项目指标管理', '6', '0', 'indicators/index', '0', '', '运动项目', '0');

-- -----------------------------
-- Table structure for `xj_model`
-- -----------------------------
DROP TABLE IF EXISTS `xj_model`;
CREATE TABLE `xj_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `type` tinyint(3) unsigned NOT NULL,
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  `pid` int(10) NOT NULL COMMENT '父id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `xj_model`
-- -----------------------------
INSERT INTO `xj_model` VALUES ('22', 'download', '下载', '{\"1\":[\"122\",\"125\",\"133\"],\"2\":[\"129\",\"127\",\"126\",\"128\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418978727', '1418979339', '1', '0', 'MyISAM', '0');
INSERT INTO `xj_model` VALUES ('18', 'base_article', '基础文档', '{\"1\":[\"82\",\"85\",\"86\"],\"2\":[\"88\",\"87\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418802016', '1418889357', '1', '0', 'MyISAM', '0');
INSERT INTO `xj_model` VALUES ('20', 'article', '文章', '{\"1\":[\"93\",\"96\",\"106\"],\"2\":[\"108\",\"107\",\"100\",\"98\",\"104\",\"105\",\"97\",\"99\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418954565', '1418965496', '1', '0', 'MyISAM', '0');

-- -----------------------------
-- Table structure for `xj_node`
-- -----------------------------
DROP TABLE IF EXISTS `xj_node`;
CREATE TABLE `xj_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) unsigned NOT NULL COMMENT '1是栏目,2是单页面,3是外部链接',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `symbol` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目英文名称',
  `pid` int(11) NOT NULL COMMENT '父级栏目',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序字段',
  `model_id` int(11) NOT NULL DEFAULT '0' COMMENT '模型',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_user` int(11) NOT NULL DEFAULT '0' COMMENT '创建者',
  `temp_category` char(40) NOT NULL DEFAULT '' COMMENT '栏目页模版',
  `temp_list` char(40) NOT NULL DEFAULT '' COMMENT '列表页模版',
  `temp_content` char(40) NOT NULL DEFAULT '' COMMENT '内容页模版',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '要跳转的url',
  `list_num` int(11) NOT NULL COMMENT '每页显示的记录数量',
  `index_show` tinyint(1) DEFAULT '1' COMMENT '是否在主页显示',
  `status` tinyint(1) DEFAULT '0' COMMENT '-1代表以删除,0代表禁用,1代表正常',
  `verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要审核',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_node`
-- -----------------------------
INSERT INTO `xj_node` VALUES ('13', '1', '运动员专区', 'yundongyuan', '0', '0', '20', '1418955957', '1418955957', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');
INSERT INTO `xj_node` VALUES ('14', '2', '运动员的责任和义务', 'zerenheyiwu', '13', '0', '19', '1418956006', '1418956006', '0', '', '', 'content.html', '', '0', '1', '1', '0');
INSERT INTO `xj_node` VALUES ('15', '1', '行踪信息申报', 'shenbao', '13', '0', '19', '1418956077', '1418956077', '0', 'category.html', 'list.html', 'content.html', '', '20', '1', '1', '0');
INSERT INTO `xj_node` VALUES ('16', '2', '相关规定', 'xiangguanguiding', '15', '0', '20', '1418956155', '1418956155', '0', '', '', 'content.html', '', '0', '1', '1', '0');
INSERT INTO `xj_node` VALUES ('17', '2', '申报流程', 'liucheng', '15', '0', '20', '1418956184', '1418956184', '0', '', '', 'content.html', '', '0', '1', '1', '0');
INSERT INTO `xj_node` VALUES ('18', '1', '下载中心', 'xiazaizhongxin', '0', '0', '22', '1418966107', '1418979380', '0', 'category.html', 'list.html', 'content.html', '', '20', '1', '1', '0');

-- -----------------------------
-- Table structure for `xj_picture`
-- -----------------------------
DROP TABLE IF EXISTS `xj_picture`;
CREATE TABLE `xj_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_picture`
-- -----------------------------
INSERT INTO `xj_picture` VALUES ('1', '/Uploads/Picture/2014-11-13/54642c43484a9.jpg', '', '71dc21797cfb7dca66515adcc4abe93b', 'f96f72d919ce79498f8608a647e5ab534c12c9ab', '1', '1415851075');
INSERT INTO `xj_picture` VALUES ('2', '/Uploads/Picture/2014-11-20/546dc0c7c7ef4.png', '', 'd8438e506d466ed38ee6b9dc4a232b40', 'b1191b0a06d36f92bb9fb21bc94daaab80265f03', '1', '1416478919');
INSERT INTO `xj_picture` VALUES ('3', '/Uploads/Picture/2014-11-21/546ec9e8d24ec.png', '', '5d1d5d4195258797a0b6fcffadcd8511', '5e6d0c581d800dd0622a76f091b2701456f8e351', '1', '1416546792');
INSERT INTO `xj_picture` VALUES ('4', '/Uploads/Picture/2014-11-21/546ed0ddc3cba.png', '', '3c838b9f71bc517a3b8028415bb59cb1', '09ac100f01411da86664b69250aba8f0b83d1491', '1', '1416548573');
INSERT INTO `xj_picture` VALUES ('5', '/Uploads/Picture/2014-11-21/546edffc7d2a6.png', '', '2f2493b43169047408921c245572d250', 'b108c0a832627b36e047a473231221e9d58619a2', '1', '1416552444');
INSERT INTO `xj_picture` VALUES ('6', '/Uploads/Picture/2014-11-21/546ee04d260c2.png', '', '333e3d1dd2ca98d7e989131b7d9a338f', '45e103b823372a5a033d9d317008c7ed218752f9', '1', '1416552525');
INSERT INTO `xj_picture` VALUES ('7', '/Uploads/Picture/2014-11-21/546ee16ca61b1.png', '', '2791e727022d2d863e17a02e57c8237f', 'eb067c0e3dbe17297247c7307b956daab3ea0bad', '1', '1416552812');
INSERT INTO `xj_picture` VALUES ('8', '/Uploads/Picture/2014-11-21/546ee1c64539c.png', '', 'f9d7f9a78cc852a599bc301cda134145', 'ef2502b45938da6de9c7321b428737eb4d9a3884', '1', '1416552902');
INSERT INTO `xj_picture` VALUES ('9', '/Uploads/picture/2014-12-19/5493ea16ba73f.png', '', '1f990d9695bf79fe5fdcd0f0840f01b7', '18abc3278d6bc1bee0af5ba2272d99b19f5554f5', '1', '1418979862');
INSERT INTO `xj_picture` VALUES ('10', '/Uploads/picture/2014-12-19/5493ea229e330.png', '', 'f321e4d05f11c423b4c76fa0730d90bc', '7d8471d49aae560c4c90986f3cef78719f1c5e59', '1', '1418979874');
INSERT INTO `xj_picture` VALUES ('11', '/Uploads/picture/2014-12-20/549550c3cf9fc.png', '', '780281674310278a3d6a3956aa3beb2f', 'e04954ee182439a53d4b751577abdc1749463d72', '1', '1419071683');

-- -----------------------------
-- Table structure for `xj_position`
-- -----------------------------
DROP TABLE IF EXISTS `xj_position`;
CREATE TABLE `xj_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(60) NOT NULL,
  `model_category` char(30) NOT NULL,
  `create_time` int(11) NOT NULL DEFAULT '0',
  `update_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_rel_position`
-- -----------------------------
DROP TABLE IF EXISTS `xj_rel_position`;
CREATE TABLE `xj_rel_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) NOT NULL,
  `model_name` char(40) NOT NULL,
  `news_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xj_sports`
-- -----------------------------
DROP TABLE IF EXISTS `xj_sports`;
CREATE TABLE `xj_sports` (
  `id` mediumint(10) NOT NULL AUTO_INCREMENT,
  `pid` mediumint(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(100) NOT NULL,
  `sort` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xj_sports`
-- -----------------------------
INSERT INTO `xj_sports` VALUES ('18', '0', '1', '游泳', '0');
INSERT INTO `xj_sports` VALUES ('19', '18', '1', '游泳', '0');
INSERT INTO `xj_sports` VALUES ('20', '19', '1', '男子', '0');
INSERT INTO `xj_sports` VALUES ('21', '20', '1', '自由泳50米', '0');
INSERT INTO `xj_sports` VALUES ('22', '20', '1', '100米', '0');
INSERT INTO `xj_sports` VALUES ('23', '20', '1', '200米', '0');
INSERT INTO `xj_sports` VALUES ('24', '20', '1', '400米', '0');
INSERT INTO `xj_sports` VALUES ('25', '20', '1', '1500米', '0');
INSERT INTO `xj_sports` VALUES ('26', '19', '1', '女子', '0');
INSERT INTO `xj_sports` VALUES ('27', '26', '1', '自由泳50米', '0');
INSERT INTO `xj_sports` VALUES ('28', '26', '1', '100米', '0');
INSERT INTO `xj_sports` VALUES ('29', '26', '1', '200米', '0');
INSERT INTO `xj_sports` VALUES ('30', '26', '1', '400米', '0');
INSERT INTO `xj_sports` VALUES ('31', '26', '1', '1500米', '0');
INSERT INTO `xj_sports` VALUES ('32', '0', '1', '田径', '0');
INSERT INTO `xj_sports` VALUES ('33', '32', '1', '田径', '0');
INSERT INTO `xj_sports` VALUES ('34', '33', '1', '男子', '0');
INSERT INTO `xj_sports` VALUES ('35', '34', '1', '20公里竞走个人', '0');
INSERT INTO `xj_sports` VALUES ('36', '34', '1', '20公里竞走团体', '0');
INSERT INTO `xj_sports` VALUES ('37', '34', '1', '50公里竞走个人', '0');
INSERT INTO `xj_sports` VALUES ('38', '33', '1', '女子', '0');
INSERT INTO `xj_sports` VALUES ('39', '38', '1', '20公里竞走个人', '0');
INSERT INTO `xj_sports` VALUES ('40', '38', '1', '20公里竞走团体', '0');
INSERT INTO `xj_sports` VALUES ('41', '38', '1', '50公里竞走个人', '0');
